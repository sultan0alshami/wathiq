export const STORAGE_KEYS = {
  AUTH: 'wathiq-auth',
  DATA_PREFIX: 'wathiq_data_',
  BACKUP_PREFIX: 'wathiq_backup_',
  SUPABASE_PREFIX: 'sb-',
} as const;


