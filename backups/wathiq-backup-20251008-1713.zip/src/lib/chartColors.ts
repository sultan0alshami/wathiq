export const CHART_COLORS = [
  'hsl(var(--wathiq-primary))',
  'hsl(var(--wathiq-accent))',
  'hsl(var(--success))',
  'hsl(var(--warning))',
  'hsl(var(--destructive))'
];
