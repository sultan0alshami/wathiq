export const ARABIC_PAGINATION_MESSAGES = {
    PREVIOUS: 'السابق',
    NEXT: 'التالي',
    ELLIPSIS_LABEL: 'صفحات أخرى',
  };
