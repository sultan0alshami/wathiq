export const ARABIC_MOBILE_NAVIGATION_MESSAGES = {
  DASHBOARD: 'لوحة التحكم',
  FINANCE: 'المالية',
  SALES: 'المبيعات',
  OPERATIONS: 'العمليات',
  MARKETING: 'التسويق',
  REPORTS: 'التقارير',
  MENU_TITLE: 'القائمة',
  MORE_BUTTON: 'المزيد',
};
