export const ARABIC_NOTES = {
  OPERATION: 'عملية',
  CUSTOMER: 'عميل',
  MEETING: 'اجتماع',
  TASK: 'مهمة',
};
