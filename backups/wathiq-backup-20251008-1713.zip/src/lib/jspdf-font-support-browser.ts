export const processText = (text: string) => text;
export const initializeEnhancedArabicFont = () => {};
