declare module 'arabic-reshaper';
