declare module 'lovable-tagger';
