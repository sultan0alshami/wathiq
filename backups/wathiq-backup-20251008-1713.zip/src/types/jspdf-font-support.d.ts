declare module 'jspdf-font-support';
