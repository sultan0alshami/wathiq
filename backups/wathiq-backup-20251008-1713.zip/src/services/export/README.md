This directory hosts export-related services. Consolidated facade remains at `src/services/ExportService.ts` for stable imports.


